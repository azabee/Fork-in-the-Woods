﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AdventureGame
{
    public partial class adventureGame : Form
    {
        public adventureGame()
        {
            InitializeComponent();
        }

        private void enterButton_Click(object sender, EventArgs e)
        {
            try
            {

                //Take user feedback and make changes to the story
                if (choiceTextBox.Text == "Begin")
                {
                    storyLabel.Text = "The Fork in the Woods\r\n\r\nYou're walking back to your cabin, along a dense forest trail that cuts through the La-Sal mountain range of south-east Utah after a long day’s hike. The sun has set and dappled moonlight highlights the path ahead of you. Your phone is dead. As you walk, you hear a low murmur in the distance. Was it the wind… or something else?\r\n\r\nUp ahead, the trail forks:\r\n\r\n'Turn Left' toward the overgrown path that leads towards the old ranger's cabin.\r\n\r\n'Turn Right', where the path leads down to Brumley Creek. \r\n";
                }
                else if (choiceTextBox.Text == "Turn Left")
                {
                    storyLabel.Text = "The Abandoned Cabin\r\n\r\nYou push your way through the undergrowth. A dilapidated cabin appears, lichen and moss grows over the slanted roof. You approach the door… and it creaks open with a push. Inside, it smells of damp earth and something else, something… musky. \r\n\r\nSuddenly, behind you, you hear a growl. A massive figure blocks off the door. Its yellow eyes glint in the moonlight, it flexes its claws menacingly.\r\n\r\n'Run into the Cabin', hoping to find a weapon or a backdoor. \r\n\r\n'Pause and Say', “What big eyes you have”, in your flirtiest voice.";
                }
                else if (choiceTextBox.Text == "Turn Right")
                {
                    storyLabel.Text = "Brumley Creek\r\n\r\nThe creek burbles soothingly. You pause to catch your breath and drink some water. Then you notice tracks in the mud—massive, canid footprints.\r\n\r\nA twig snaps behind you.\r\n\r\nA deep voice growls, “You shouldn’t have come here alone.”\r\n\r\n'Run back' the way you came. \r\n\r\n'Turn Slowly' and say, \"Aren’t you the park ranger from Grindr ?";
                }
                else if (choiceTextBox.Text == "Run into the Cabin")
                {
                    storyLabel.Text = "You run.\r\n\r\nYour heart pounds in your chest, your breathing is ragged. Behind you, you hear paws pounding, closing the distance between you. You reach the massive drop off of a ravine. Dead end. You turn, just as the werewolf pounces.\r\n\r\nYou are eaten, and not quickly, either. You should’ve swiped right on that werewolf instead.\r\n\r\nTHE END.\r\nWould you like to ‘Try Your Luck’ again?\r\n";
                }
                else if (choiceTextBox.Text == "Pause and Say")
                {
                    storyLabel.Text = "A Date to Dismember\r\n\r\nYou don’t run. You don’t scream. You meet those glowing eyes and say something that surprises even you:\r\n“Look, I know this is going to sound weird, but… would you go out with me sometime?”\r\n\r\nThe werewolf blinks. His growl quiets. He tilts his head and smirks.\r\n\r\n“…You’re either brave or stupid... I like it.”\r\n\r\nHe steps back, giving you some space. You walk together under the moonlight, talking about forest survival tips and favorite blood types.\r\n\r\nTurns out, his name is Raul, he likes his steak cooked rare, moonlit walks, and indie folk music.\r\n\r\nYou’re not eaten, you’re dating a werewolf!\r\n\r\nTHE END(?)\r\nWould you like to ‘Try Your Luck’ again?\r\n";
                }
                else if (choiceTextBox.Text == "Run Back")
                {
                    storyLabel.Text = "The End You Feared\r\n\r\nYou run.\r\n\r\nYour heart pounds in your chest, your breathing is ragged. Behind you, you hear paws pounding, closing the distance between you. You reach the massive drop off of a ravine. Dead end. You turn, just as the werewolf pounces.\r\n\r\nYou are eaten, and not quickly, either. You should’ve swiped right on that werewolf instead.\r\n\r\nTHE END.\r\nWould you like to ‘Try Your Luck’ again?\r\n";
                }
                else if (choiceTextBox.Text == "Turn Slowly")
                {
                    storyLabel.Text = "A Date to Dismember\r\n\r\nYou don’t run. You don’t scream. You meet those glowing eyes and say something that surprises even you:\r\n“Look, I know this is going to sound weird, but… would you go out with me sometime?”\r\n\r\nThe werewolf blinks. His growl quiets. He tilts his head and smirks.\r\n\r\n“…You’re either brave or stupid... I like it.”\r\n\r\nHe steps back, giving you some space. You walk together under the moonlight, talking about forest survival tips and favorite blood types.\r\n\r\nTurns out, his name is Raul, he likes his steak cooked rare, moonlit walks, and indie folk music.\r\n\r\nYou’re not eaten, you’re dating a werewolf!\r\n\r\nTHE END(?)\r\nWould you like to ‘Try Your Luck’ again?\r\n";
                }
                else if (choiceTextBox.Text == "Try Your Luck")
                {
                    storyLabel.Text = "You're walking back to your cabin, along a dense forest trail that cuts through the La-Sal mountain range of south-east Utah after a long day’s hike. The sun has set and dappled moonlight highlights the path ahead of you. Your phone is dead. As you walk, you hear a low murmur in the distance. Was it the wind… or something else?\r\n\r\nUp ahead, the trail forks:\r\n\r\nTurn left toward the overgrown path that leads towards the old ranger's cabin.\r\n\r\nTurn right, where the path leads down to Brumley Creek. \r\n\r\n";
                }
                else
                {
                    MessageBox.Show("Check your spelling.");
                }
            }
            catch
            {

            }   
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            choiceTextBox.Clear();

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
